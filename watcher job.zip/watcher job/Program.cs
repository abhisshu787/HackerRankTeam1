﻿using System;

using System.IO;

using System.Data.SqlClient;

using Newtonsoft.Json;

using Newtonsoft.Json.Linq;




namespace PenaltyComputationJob

{

    class Program

    {

        static void Main(string[] args)

        {

            string filePath = @"C:\Users\POURDK\Downloads\transaction_feed (1).txt"; // Path to your penalty text file

            //string connectionString = "your_connection_string"; // Connection string to your database




            try

            {

                // Read the penalty data from the text file

                //string[] penaltyData = File.ReadAllLines(filePath);




                /*JObject jsonData = JObject.Parse(penaltyData);




                string id*/

               

               List<string> lines = new List<string>();

               

                lines = File.ReadAllLines(filePath).ToList();




                foreach(string line in  lines)

                {

                    Console.WriteLine(line);

                }




                /*foreach (string penaltyInfo in penaltyData)

                {

                    // Extract the relevant information from the penalty data

                    //string[] penaltyFields = penaltyInfo.Split(',');

                    Console.WriteLine(penaltyInfo);




                    //string userId = penaltyFields[0]; // Assuming user ID is the first field

                    //int penaltyAmount = int.Parse(penaltyFields[1]); // Assuming penalty amount is the second field




                    // Calculate penalties (replace this with your own logic)

                    //int totalPenalty = CalculatePenalty(penaltyAmount);




                    // Update the database with the calculated penalty

                    //UpdateDatabase(connectionString, userId, totalPenalty);




                    //Console.WriteLine(userId);

                }*/




               




                Console.WriteLine("Penalty computation completed successfully!");

            }

            catch (Exception ex)

            {

                Console.WriteLine("Error occurred: " + ex.Message);

            }




            Console.ReadLine();

        }




        /*static int CalculatePenalty(int penaltyAmount)

        {

            // Add your own penalty calculation logic here

            // For example, you can apply some business rules or formulas




            // For demonstration purposes, let's assume a 10% penalty on the original amount

            return (int)(penaltyAmount * 0.1);

        }




        static void UpdateDatabase(string connectionString, string userId, int penaltyAmount)

        {

            using (SqlConnection connection = new SqlConnection(connectionString))

            {

                string query = "UPDATE Users SET PenaltyAmount = @penaltyAmount WHERE UserId = @userId";




                using (SqlCommand command = new SqlCommand(query, connection))

                {

                    command.Parameters.AddWithValue("@penaltyAmount", penaltyAmount);

                    command.Parameters.AddWithValue("@userId", userId);




                    connection.Open();

                    command.ExecuteNonQuery();

                    connection.Close();

                }

            }

        }*/

    }

}